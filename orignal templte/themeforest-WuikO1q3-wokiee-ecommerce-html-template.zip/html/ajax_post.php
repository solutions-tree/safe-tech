  <?php
  echo '<div class="element-item">
                        <div class="tt-post">
                            <div class="tt-post-img">
                                <a href="blog-single-post.html"><img src="images/blog/masonry/masonry-img-01.jpg" alt=""></a>
                            </div>
                            <div class="tt-post-content">
                                <div class="tt-background"></div>
                                <div class="tt-tag"><a href="#">FASHION</a></div>
                                <h2 class="tt-title"><a href="blog-single-post.html">DOLORE EU FUGIATNULLA PARIATUR</a></h2>
                                <div class="tt-description">
                                    Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                </div>
                                <div class="tt-meta">
                                    <div class="tt-autor">
                                        by <span>ADRIAN</span> on January 14, 2017
                                    </div>
                                    <div class="tt-comments">
                                        <a href="#"><i class="tt-icon icon-h-11"></i>7</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>';
?>